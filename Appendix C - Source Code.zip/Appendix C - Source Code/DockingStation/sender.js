const request = require('request');

var path = require('path');
var fs = require('fs');

let ds_id = 0;

let currentSurvey = "";
let surveyflag = false;



let test_connection = function(){
    request('http://localhost:62286/Drone/getID', { json: true }, (err, res, body) => {
      if (err) { return console.log(err); }
      console.log(body);
      //console.log(res)
    });
}

let get_pending_surveys = () => {
    request('http://localhost:62286/Drone/SurveyAsync?ds_id=' + 6, { json: true }, (err, res, body) => {
      if (err) { return console.log(err); }
      console.log(body);
      currentSurvey = body;
      surveyflag = true;
      //console.log(res)
    });
    setTimeout(get_pending_surveys, 3000)
}



let getId = () => {
  fs.readFile(path.join(__dirname, '/id.txt'), 'utf8', function (err, data) {
        if (err) {
          return console.log(err);
        }
        if(data === "") {
            request('http://localhost:62286/Drone/getID', { json: true }, (err, res, body) => {
              if (err) { return console.log(err); }
              fs.writeFile(path.join(__dirname, '/id.txt'), "" + body, function(err) {
                  if(err) { return console.log(err);  }
               });
               ds_id = body;
               console.log("Saved:", ds_id)
            });
        }
        else {
              ds_id = data;
              console.log("ID already exists:", ds_id)
        }
  });
  get_pending_surveys();
}


exports.start = () => {
  getId();
}
exports.hasSurvey = () => {
  return surveyflag;
}
exports.getNextSurvey = () => {
  surveyflag = false;
  return currentSurvey;
}

exports.send = (attachment) => {

}
