from PIL import Image,ImageDraw, ImageFont
import time
import matplotlib.path as mplPath
import numpy as np

class WaypointGenerator:
	class Waypoint:
		def __init__(self,x, y):
			self.X = x
			self.Y = y
		
	def __init__(self, im):
		self.Coordinates = []
		
		print ("\nLoading Image")
		background = Image.open("area.jpg")
		fieldimage = np.array(background)
		imout = np.array(fieldimage)
		#background.show()
		
		#defining the polygon and adding it to matplot path
		poly = [125,51,796,176,787,305,814,433,872,527,921,742,776,815,420,677,427,542,499,510,521,400,480,370,293,410,276,613,90,562,125,51]
		length = len(poly)/2
		new_array = []

		p,i=0,0
		while True :
			new_array.append([poly[p],poly[p+1]])
			p = p + 2
			i = i + 1
			if i == length:
				break
		
		field_path = mplPath.Path(new_array)
		
		#setup the image draw/composite 
		print("Starting")
		t0 = time.time()
		size = width, height = background.size
		background = background.convert("RGBA")
		
		fill_red = (255,0,0,50)
		fill_green = (0,255,0,50)
		color_layer_red = Image.new('RGBA', background.size, fill_red)
		color_layer_green = Image.new('RGBA', background.size, fill_green)


		alpha_mask0 = Image.new('L', background.size, 0)
		alpha_mask_draw0 = ImageDraw.Draw(alpha_mask0).polygon(poly,fill=50,outline="black")

		alpha_mask1 = Image.new('L', background.size, 0)
		alpha_mask_draw1 = ImageDraw.Draw(alpha_mask1)

	
		#going through image and marking waypoints and drawing rectangles
		x,y,i,w = 0,0,0,0
		boo = False
		print("Creating Waypoints")
		while True :
			x0 = x - 10;x1 = x + 10;y0 = y - 10;y1 = y + 10;
			if field_path.contains_point((x,y)):
				alpha_mask_draw1.rectangle([(x0,y0),(x1,y1)] , fill=50)
				text = str(w)
				wp = WaypointGenerator.Waypoint(x,y)
				self.Coordinates.append(wp)
				w = w + 1
				alpha_mask_draw1.text((x0+8,y0+5),text, fill="#ffffff", font=None)
				boo = True
			elif field_path.contains_point((x-10,y)):
				alpha_mask_draw1.rectangle([(x0-5,y0),(x1-5,y1)] , fill=50)
				text = str(w)
				wp = WaypointGenerator.Waypoint(x,y)
				self.Coordinates.append(wp)
				w = w + 1
				alpha_mask_draw1.text((x0+8,y0+5),text, fill="#ffffff", font=None)
				boo = True				
			if x > width :
				x = 0
				if boo :
					y = y+20					
					boo = False
				else:
					y = y+1
			if y > height :
				break
			if boo :
				x = x +20
			else:
				x = x+1
			i = i +1
		
		print("Total waypoints: ", w)
		print("Compositing Image")
		background = Image.composite(color_layer_red, background, alpha_mask0)
		#background.show()
		background.save("field.png")	
		background = Image.composite(color_layer_green, background, alpha_mask1)
			
		t1 = time.time()
		totaltime = t1-t0
		print("Time elapsed: ",totaltime, "\n")
		#background.show()
		
		background.save("result.png")		
		
