"""
Dependencies to install:
python -mpip install -U matplotlib
pip install numpy
pip install Pillow  or python3 -m pip install Pillow
pip install geojson
"""
import matplotlib.path as mplPath
import numpy as np
import time
import argparse
import json
import geojson
from pprint import pprint
from waypoint import WaypointGenerator
from missionplanner import MissionPlanner
from survey import Survey

#arguments
parser = argparse.ArgumentParser()
parser.add_argument("input_file")
args = parser.parse_args()

#importing json data
with open('field1.json') as data_file:
    data = json.load(data_file)

#starting waypoint generator
wg = WaypointGenerator(args.input_file)

#selecting data from json
mycord = [int,int]
mycord = data["features"][0]["geometry"]["coordinates"][1]

#waypoint coordinates
myCoordinates = {}
myCoordinates = wg.Coordinates
mp = MissionPlanner(myCoordinates)
	
#converting our missionlist into proper geojson
myFeature = geojson.LineString(mp.Mission)
geoFeature = geojson.Feature(geometry=myFeature)
geoCollection = geojson.FeatureCollection([geoFeature])

#writing new json file
with open('field2.json','w') as f:
	json.dump(geoCollection,f,indent=4)	
mysurvey = Survey()



