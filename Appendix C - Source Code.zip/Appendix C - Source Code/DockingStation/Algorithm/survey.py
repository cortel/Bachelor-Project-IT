from PIL import Image,ImageDraw, ImageFont
import random
import matplotlib.path as mplPath
import numpy as np
import time

class Survey:
	def __init__(self):	
		t0 = time.time()
		
		"""
		for x in range(0,1000):
			r,g,b = random.randint(1, 255),random.randint(1, 255),random.randint(1, 255)
			intcolor = (0<<16)|(g<<8)|r
			n = Image.new("RGB",(100,100), intcolor)
			#m = ImageDraw.Draw(n)
			#m.rectangle(((0,0),(100,100)),rand)
			n.save('images/'+str(x)+'.png')
		"""
		
		poly = [125,51,796,176,787,305,814,433,872,527,921,742,776,815,420,677,427,542,499,510,521,400,480,370,293,410,276,613,90,562,125,51]	
		length = len(poly)/2
		new_array = []
		p,i=0,0
		while True :
			new_array.append([poly[p],poly[p+1]])
			p = p + 2
			i = i + 1
			if i == length:
				break
		field_path = mplPath.Path(new_array)
		field_image = Image.open("area.jpg")
		size = width, height = field_image.size
		
		
		x,y,i,w,c = 0,0,0,0,0
		boo = False
		print("Compositing Survey")
		while True :
			x0 = x - 10;x1 = x + 10;y0 = y - 10;y1 = y + 10;
			if field_path.contains_point((x,y)):
				survey_sample = Image.open("images/%01d.png"%c)
				c = c+1
				r,g,b = survey_sample.getpixel((0,0))
				survey_mask = Image.new('L', field_image.size, 0)
				
				survey_mask_draw = ImageDraw.Draw(survey_mask)
				survey_mask_draw.rectangle([(x0,y0),(x1,y1)] , fill=80)
				
				#r,g,b = random.randint(1, 255),random.randint(1, 255),random.randint(1, 255)
				
				randcolor = (r,g,b,70)
				color_layer = Image.new('RGBA', field_image.size, randcolor)
				field_image = Image.composite(color_layer, field_image, survey_mask)
				boo = True
			if x > width :
				x = 0
				if boo :
					y = y+20
					boo = False
				else:
					y = y+1
			if y > height :
				break
			if boo :
				x = x +20
			else:
				x = x+1
			i = i +1


		t1 = time.time()
		totaltime = t1-t0
		print("Time elapsed: ",totaltime, "\n")
		
		field_image.save("survey.png")
		field_image.show()
		