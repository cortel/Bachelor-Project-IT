class Field:	
	def __init__(self, im):		
		width = im.width;
		height = im.height;