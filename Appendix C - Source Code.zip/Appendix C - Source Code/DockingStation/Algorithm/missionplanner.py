class MissionPlanner :	
	def __init__(self, dict):
		self.Table = dict
		self.Mission = []
		self.Ratio1 = 0
		self.Ratio2 = 0	
		
		#top left gps coords of the image
		long1 = 9.863950574635055
		lat1 = 55.88785397581593		
		
		#bottom right gps coords of the image 
		long2 = 9.876460397480514
		lat2 = 55.88186219806053
		
		#dimiension of the image
		x1 = 0
		y1 = 0
		x2 = 986
		y2 = 854

		self.Ratio1 = abs(long2-long1)/abs(x2-x1)
		self.Ratio2 = abs(lat2-lat1)/abs(y2-y1)
		
		temp2 = self.Table
		n = []
		i = 0
		for x in temp2:
			n=[long1 + (x.X * self.Ratio1), lat1 + (x.Y * -self.Ratio2)]
			i = i +1
			self.Mission.append(n)
			