const express = require('express');
const app = express();
const bodyParser = require('body-parser');
var path = require('path');
app.use(bodyParser.text());

//test_connection();
app.post('/', bodyParser.json(), function (req, res) {
  console.log(req.body);
  if(req.body) res.send("REPOSTING");
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});

//test_connection();
