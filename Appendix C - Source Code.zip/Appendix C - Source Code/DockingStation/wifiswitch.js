var WiFiControl = require('wifi-control');

let drone_setting;
let network_setting;

exports.connect = function(settings) {
    var results = WiFiControl.connectToAP( setting, function(err, response) {
        if (err) console.log(err);
        console.log(response);
    });
}

exports.init = function() {
  //  Initialize wifi-control package with verbose output
    WiFiControl.init({
      debug: true
    });

    network_setting = {
      ssid: "VIA",
      user: '224469@via.dk',
      password: ""
    };
    drone_setting = {
      ssid: "Drone_ssid"
    };
}
