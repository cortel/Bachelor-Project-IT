let sender = require('./sender.js');

sender.start();
sender.send();