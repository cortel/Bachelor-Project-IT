﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using DroneSystem.Models;
using Microsoft.AspNetCore.Authorization;
using DroneSystem.Models.Database;
using DroneSystem.Models.Auth;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;

namespace DroneSystem.Controllers
{
    public class DroneController : Controller
    {
        private DatabaseContext db;
        public DroneController(DatabaseContext db)
        {
            this.db = db;
        }

        [HttpGet]
        [Authorize]
        public String Test()
        {
            var claims = User.Claims;
            var headers = ControllerContext.HttpContext.Request.Headers.ToString();

            return "Success!";
        }

        public async Task<string> Test_PostAsync()
        {
            var payload = new User
            {
                email = "asd",
                name = "asd",
                is_admin = 1,
                password = "asd"

            };
            var stringPayload = await Task.Run(() => JsonConvert.SerializeObject(payload));
            var httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");
            using (var client = new HttpClient())
            {
                HttpResponseMessage res = await client.PostAsync("http://localhost:3000/", httpContent);
                return await res.Content.ReadAsStringAsync();
            }

        }
        public IActionResult CreateCookie(String email, String password)
        {
            
            //var token = new JwtTokenBuilder()  
            //            .Build();
            //Response.Cookies.Append("token", token);
            return View();//new ObjectResult(token);

        }

        [HttpGet]
        public string getID()
        {
            DockingStation ds = new DockingStation { ds_id = null, ssid = null };

            db.DockingStation.Add(ds);
            db.SaveChanges();

            var query = from e in db.DockingStation
                        select e;

            return query.ToList().Last().ds_id.ToString(); 
        }

        [HttpGet]
        public string SurveyAsync(int ds_id)
        {
            var field = (from e in db.Field
                        where e.ds_id == ds_id
                        select e).First();
            var survey = (from e in db.Survey
                          where e.field_id == field.field_id
                          select e).ToList().Count;
            if(survey == 0)
            {
                return "";
            }   
            return JsonConvert.SerializeObject(field.coordinates);
        }
    }
}